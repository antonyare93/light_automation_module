/*
 * SPDX-FileCopyrightText: 2024 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#pragma once

#ifdef __cplusplus
extern "C" {
#endif

#include "esp_cam_sensor_types.h"
#include "sc035hgs_types.h"

#define SC035HGS_SCCB_ADDR   0x30
#define SC035HGS_PID         0x0031
#define SC035HGS_SENSOR_NAME "SC035HGS"

/**
 * @brief Power on camera sensor device and detect the device connected to the designated sccb bus.
 *
 * @param[in] config Configuration related to device power-on and detection.
 * @return
 *      - Camera device handle on success, otherwise, failed.
 */
esp_cam_sensor_device_t *sc035hgs_detect(esp_cam_sensor_config_t *config);

#ifdef __cplusplus
}
#endif
