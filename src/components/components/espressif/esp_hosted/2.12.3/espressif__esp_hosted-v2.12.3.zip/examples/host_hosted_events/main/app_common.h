/*
 * SPDX-FileCopyrightText: 2025-2026 Espressif Systems (Shanghai) CO LTD
 *
 * SPDX-License-Identifier: Apache-2.0
 */
#ifndef __APP_COMMON_H__
#define __APP_COMMON_H__

void example_wifi_init_once(void);
void example_wifi_init_sta(void);
void example_wifi_deinit_sta(void);
void example_wifi_sta_netif_close(void);

#endif
